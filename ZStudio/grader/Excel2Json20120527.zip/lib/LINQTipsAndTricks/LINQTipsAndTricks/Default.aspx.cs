﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccess;
using System.Xml.Serialization;
using Newtonsoft.Json;

namespace LINQTipsAndTricks
{
    public partial class _Default : System.Web.UI.Page
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            btnWithoutLoadOptions.Click += new EventHandler(btnWithoutLoadOptions_Click);
            btnWithLoadOptions.Click += new EventHandler(btnWithLoadOptions_Click);

            btnDeferredLoadingEnabled.Click += new EventHandler(btnDeferredLoadingEnabled_Click);
            btnDeferredLoadingDisabled.Click += new EventHandler(btnDeferredLoadingDisabled_Click);
            btnContextDisposedError.Click += new EventHandler(btnContextDisposedError_Click);

            btnQueryBuilding.Click += new EventHandler(btnQueryBuilding_Click);

            btnDynamicQueryGetProductNumber.Click += new EventHandler(btnDynamicQueryGetProductNumber_Click);

            btnStoreProduct.Click += new EventHandler(btnStoreProduct_Click);
            btnReturnProduct.Click += new EventHandler(btnReturnProduct_Click);

            btnAttachGetProductNumber.Click += new EventHandler(btnAttachGetProductNumber_Click);

            btnDateDiffAndLikeUse.Click += new EventHandler(btnDateDiffAndLikeUse_Click);
        }

        void btnWithoutLoadOptions_Click(object sender, EventArgs e)
        {
            lblLoadOptionsProductSubcategory.Text = LoadOptionsDemo.QueryWithNoLoadOptions();
        }

        void btnWithLoadOptions_Click(object sender, EventArgs e)
        {
            lblLoadOptionsProductSubcategory.Text = LoadOptionsDemo.QueryWithLoadOptions();
        }

        void btnDeferredLoadingEnabled_Click(object sender, EventArgs e)
        {
            lblDeferredLoadingProductSubcategory.Text = DeferredLoadingDemo.QueryWithDefferedLoadinEnabled();
        }

        void btnDeferredLoadingDisabled_Click(object sender, EventArgs e)
        {
            lblDeferredLoadingProductSubcategory.Text = DeferredLoadingDemo.QueryWithDefferedLoadinDisabled();
        }

        void btnContextDisposedError_Click(object sender, EventArgs e)
        {
            lblDeferredLoadingProductSubcategory.Text = DeferredLoadingDemo.DataContextDisposedError();
        }

        void btnQueryBuilding_Click(object sender, EventArgs e)
        {
            lblQueryBuildingProductNumber.Text = QueryBuildingDemo.BuildQuery(1);
        }

        void btnDynamicQueryGetProductNumber_Click(object sender, EventArgs e)
        {
            lblDynamicQueryProductNumber.Text = DynamicQueryDemo.GetSomeProductNumber();            
        }
        
        void btnStoreProduct_Click(object sender, EventArgs e)
        {
            Product product = LinqAndWebDemo.GetSomeProduct();
            Session["product"] = product;
            Application["product"] = product;
            ViewState["product"] = JsonConvert.SerializeObject(product);
            Cache["product"] = product;
            
        }

        void btnReturnProduct_Click(object sender, EventArgs e)
        {
            Product product = (Product)Session["product"];
            product = (Product)Application["product"];
            
            //Notice that product subcategory is assigned
            product = JsonConvert.DeserializeObject<Product>(ViewState["product"] as string);
            
            product = (Product)Cache["product"];
        }

        void btnAttachGetProductNumber_Click(object sender, EventArgs e)
        {
            AttachDemo.DeserializeAttachUpdate();
        }

        void btnDateDiffAndLikeUse_Click(object sender, EventArgs e)
        {
            DateDiffAndLikeDemo.RunExample();
        }
    }
}
