﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq.SqlClient;

namespace DataAccess
{
    public static class DateDiffAndLikeDemo
    {
        public static void RunExample()
        {
            using (AdventureWorksDataContext db = new AdventureWorksDataContext())
            {
                /*
                 This will produce the following query:
                    SELECT [t0].[ProductCategoryID], [t0].[Name], [t0].[rowguid], [t0].[ModifiedDate]
                    FROM [Production].[ProductCategory] AS [t0]
                    WHERE [t0].[Name] LIKE '%ike%'                 
                 */
                ProductCategory pc = db.ProductCategories.Where(o => SqlMethods.Like(o.Name, "%ike%")).FirstOrDefault();

                /*
                  This will produce the following query:
                    SELECT TOP (1) [t0].[ProductCategoryID], [t0].[Name], [t0].[rowguid], [t0].[ModifiedDate]
                    FROM [Production].[ProductCategory] AS [t0]
                    WHERE DATEDIFF(Year, [t0].[ModifiedDate], @p0) > 1                 
                 
                    Where @p0 is equal to DateTime.Now value we passed 
                 */
                pc = db.ProductCategories.Where(o => SqlMethods.DateDiffYear(o.ModifiedDate, DateTime.Now) > 1).FirstOrDefault();
            }            
        }
    }
}
