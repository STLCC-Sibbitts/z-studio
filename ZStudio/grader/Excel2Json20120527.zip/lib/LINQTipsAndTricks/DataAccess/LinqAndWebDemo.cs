﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

namespace DataAccess
{
    public class LinqAndWebDemo
    {
        public static Product GetSomeProduct()
        {
            using (AdventureWorksDataContext db = new AdventureWorksDataContext())
            {
                db.DeferredLoadingEnabled = false;

                DataLoadOptions loadOptions = new DataLoadOptions();
                loadOptions.LoadWith<Product>(o => o.ProductSubcategory);
                db.LoadOptions = loadOptions;
                return db.Products.Where(o => o.ProductSubcategoryID != null).FirstOrDefault();
            }
        }
    }
}
