﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

namespace DataAccess
{
    public static class LoadOptionsDemo
    {
        public static string QueryWithNoLoadOptions()
        {
            using (AdventureWorksDataContext db = new AdventureWorksDataContext())
            {
                //First query is executed. The query returns one product.
                Product product = db.Products.Where(o => o.ProductSubcategoryID != null).FirstOrDefault();

                //Second query is executed. The query returns the subcategory for the previous product.
                if (product.ProductSubcategory != null)
                {                    
                    return product.ProductSubcategory.Name;
                }

                return "";
            }
        }

        public static string QueryWithLoadOptions()
        {
            using (AdventureWorksDataContext db = new AdventureWorksDataContext())
            {
                DataLoadOptions loadOptions = new DataLoadOptions();                
                loadOptions.LoadWith<Product>(o => o.ProductSubcategory);
                db.LoadOptions = loadOptions;
                
                //One query is executed. The query returns the one product and its subcategory using an left outer join
                Product product = db.Products.Where(o => o.ProductSubcategoryID != null).FirstOrDefault();

                if (product.ProductSubcategory != null)
                {
                    return product.ProductSubcategory.Name;
                }

                return "";
            }
        }
    }
}
