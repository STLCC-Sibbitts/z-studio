﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;

namespace DataAccess
{
    public static class AttachDemo
    {
        public static void DeserializeAttachUpdate()
        {           
            ProductCategory changedProductCategory = null;

            using (AdventureWorksDataContext db = new AdventureWorksDataContext())
            {
                db.DeferredLoadingEnabled = false;

                changedProductCategory = db.ProductCategories.FirstOrDefault();
                //change modified date
                changedProductCategory.ModifiedDate = DateTime.Now;                
            }

            string json = JsonConvert.SerializeObject(changedProductCategory);

            //re-create the object
            changedProductCategory = JsonConvert.DeserializeObject<ProductCategory>(json);


            ProductCategory originalProductCategory = null;

            //create second context to get original entity
            using (AdventureWorksDataContext db = new AdventureWorksDataContext())
            {
                originalProductCategory = db.ProductCategories.Where(o => o.ProductCategoryID == changedProductCategory.ProductCategoryID).FirstOrDefault();
            }

            //create third context to do the update
            using (AdventureWorksDataContext db = new AdventureWorksDataContext())
            {
                db.ProductCategories.Attach(changedProductCategory, originalProductCategory);

                //Here an update query is executed and ModifiedDate is updated in the database. Notice that the column that changed is determined aautomatically. 
                db.SubmitChanges();
            }
        }
    }
}
