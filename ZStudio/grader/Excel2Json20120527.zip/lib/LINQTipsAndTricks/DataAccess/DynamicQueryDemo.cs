﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Dynamic;

namespace DataAccess
{
    public class DynamicQueryDemo
    {
        public static string GetSomeProductNumber()
        {
            using (AdventureWorksDataContext db = new AdventureWorksDataContext())
            {
                Product product = db.Products.Where("ProductSubcategoryID != null").OrderBy("ProductNumber").FirstOrDefault();
                return product.ProductNumber;
            }
        }
    }
}
