﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess
{
    public static class QueryBuildingDemo
    {
        public static string BuildQuery(int caseNumber)
        {
            using (AdventureWorksDataContext db = new AdventureWorksDataContext())
            {
                var products = db.Products.Where(o => o.ProductSubcategoryID != null);

                switch (caseNumber)
                {
                    case 1:
                        products = products.OrderBy(o => o.ProductNumber);
                        break;
                    case 2:
                        products = products.Where(o => o.ProductModelID != null);
                        break;
                }

                /*
                 The query will be executed only here and will look like this:
                    SELECT TOP (1) [t0].[ProductID], [t0].[Name], [t0].[ProductNumber], [t0].[MakeFlag], [t0].[FinishedGoodsFlag], [t0].[Color], [t0].[SafetyStockLevel], [t0].[ReorderPoint], [t0].[StandardCost], 
                    [t0].[ListPrice], [t0].[Size], [t0].[SizeUnitMeasureCode], [t0].[WeightUnitMeasureCode], [t0].[Weight], [t0].[DaysToManufacture], [t0].[ProductLine], [t0].[Class], [t0].[Style], 
                    [t0].[ProductSubcategoryID], [t0].[ProductModelID], [t0].[SellStartDate], [t0].[SellEndDate], [t0].[DiscontinuedDate], [t0].[rowguid], [t0].[ModifiedDate]
                    FROM [Production].[Product] AS [t0]
                    WHERE [t0].[ProductSubcategoryID] IS NOT NULL
                    ORDER BY [t0].[ProductNumber]
                 */
                Product product = products.FirstOrDefault();

                return product.ProductNumber;
            }
        }
    }
}
