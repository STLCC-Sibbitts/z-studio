﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess
{
    public class DeferredLoadingDemo
    {
        public static string QueryWithDefferedLoadinEnabled()
        {
            using (AdventureWorksDataContext db = new AdventureWorksDataContext())
            {
                db.DeferredLoadingEnabled = true;//this is the default value

                //First query is executed. The query returns one product.
                Product product = db.Products.Where(o => o.ProductSubcategoryID != null).FirstOrDefault();

                //Second query is executed. The query returns the subcategory for the previous product.
                if (product.ProductSubcategory != null)
                {
                    return product.ProductSubcategory.Name;
                }

                return "";
            }
        }

        public static string QueryWithDefferedLoadinDisabled()
        {
            using (AdventureWorksDataContext db = new AdventureWorksDataContext())
            {
                db.DeferredLoadingEnabled = false;

                //First query is executed. The query returns one product.
                Product product = db.Products.Where(o => o.ProductSubcategoryID != null).FirstOrDefault();

                //ProductSubcategory will always be null
                if (product.ProductSubcategory != null)
                {
                    //this will never be executed
                    return product.ProductSubcategory.Name;
                }

                return "";
            }
        }

        public static string DataContextDisposedError()
        {
            Product product = null;

            using (AdventureWorksDataContext db = new AdventureWorksDataContext())
            {
                db.DeferredLoadingEnabled = true;//this is the default value

                product = db.Products.Where(o => o.ProductSubcategoryID != null).FirstOrDefault();
            }
            //this will raise an error - Cannot access a disposed object.
            return product.ProductSubcategory.Name;
        }
    }
}
