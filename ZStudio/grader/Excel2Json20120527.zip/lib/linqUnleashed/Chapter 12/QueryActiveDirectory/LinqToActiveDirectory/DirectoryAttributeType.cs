﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinqToActiveDirectory
{
  public enum DirectoryAttributeType
  {
    Ldap,
    ActiveDs
  }
}