namespace SqlDesignerExample
{
  partial class CustomerDataContext
  {
  }
}
